import React from "react";

const Payments = () => {
  return (
    <div>
      <h1>Payments</h1>
      {/* Implement payments management here */}
    </div>
  );
};

export default Payments;
